﻿using AutoMoska.ClassEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static AutoMoska.ClassEntity.Worker;


namespace AutoMoska.AddWindows
{
    /// <summary>
    /// Логика взаимодействия для AddWorker.xaml
    /// </summary>
    public partial class AddWorker : Window
    {
        public AddWorker()
        {
            InitializeComponent();
        }
        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            Regex regexWord = new Regex(@"^[А-Я][а-я]{1,20}$");
            Regex regexNumber = new Regex(@"^(?:\+7|8)\d{10}$");

            if (string.IsNullOrWhiteSpace(WorkerFirstName.Text) && string.IsNullOrWhiteSpace(WorkerPhoneNumber.Text) && string.IsNullOrWhiteSpace(WorkerLastName.Text) && string.IsNullOrWhiteSpace(WorkerPatronymic.Text) && string.IsNullOrWhiteSpace(WorkerPost.Text) && string.IsNullOrWhiteSpace(WorkerLogin.Text) && string.IsNullOrWhiteSpace(WorkerPassword.Text))
            {
                MessageBox.Show("Необходимо заполнить данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if ((WorkerFirstName.Text != "") && (WorkerPhoneNumber.Text != "") && (WorkerLastName.Text != "") && (WorkerPatronymic.Text != "") && (WorkerPost.Text != "") && (WorkerLogin.Text != "") && (WorkerPassword.Text != ""))
            {
                try
                {
                    if (regexWord.IsMatch(WorkerFirstName.Text))
                    {
                        if (regexWord.IsMatch(WorkerLastName.Text))
                        {
                            if (regexWord.IsMatch(WorkerPatronymic.Text))
                            {
                                    if (regexNumber.IsMatch(WorkerPhoneNumber.Text))
                                    {
                                        Worker _tempWorker = new Worker();
                                        _tempWorker.FirstName = WorkerFirstName.Text;
                                        _tempWorker.LastName = WorkerLastName.Text;
                                        _tempWorker.Patronymic = WorkerPatronymic.Text;
                                        _tempWorker.Post = WorkerPost.Text;
                                        _tempWorker.Login = WorkerLogin.Text;
                                        _tempWorker.Password = WorkerPassword.Text;
                                        _tempWorker.Phone = WorkerPhoneNumber.Text;

                                        DatabaseControl.AddWorker(new Worker
                                        {
                                            FirstName = WorkerFirstName.Text,
                                            LastName = WorkerLastName.Text,
                                            Patronymic = WorkerPatronymic.Text,
                                            Post = WorkerPost.Text,
                                            Login = WorkerLogin.Text,
                                            Password = WorkerPassword.Text,
                                            Phone = WorkerPhoneNumber.Text
                                            //Discount = (int)Convert.ToDecimal(Worker.Text)
                                        });

                                        gridRefFive.grid.ItemsSource = null;
                                        gridRefFive.grid.ItemsSource = DatabaseControl.GetWorkerForView();
                                        this.Close();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Неверно указан номер телефона", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                    }
                            }
                            else
                            {
                                MessageBox.Show("Неверный формат отчества клиента", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Неверный формат фамилии клиента", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Неверный формат имени клиента", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch
                {
                    MessageBox.Show("Необходимо заполнить данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
