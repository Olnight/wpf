﻿using AutoMoska.ClassEntity;
using AutoMoska.AddWindows;
using AutoMoska.EditWindows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static AutoMoska.ClassEntity.Service;

namespace AutoMoska.Pages
{
    /// <summary>
    /// Логика взаимодействия для ServicePage.xaml
    /// </summary>
    public partial class ServicePage : Page
    {
        public ServicePage()
        {
            InitializeComponent();
            ServiceDataGridView.ItemsSource = DatabaseControl.GetServiceForView();
        }
        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            AddService win = new AddService();
            gridRefFour.grid = ServiceDataGridView;
            win.ShowDialog();
        }
        private void editButton_Click(object sender, RoutedEventArgs e)
        {

            Service c = ServiceDataGridView.SelectedItem as Service;
            gridRefFour.grid = ServiceDataGridView;
            if (c != null)
            {
                EditService eddService = new EditService(c);
                eddService.Show();
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }
        }
        public void RefreshTable()
        {
            ServiceDataGridView.ItemsSource = null;
            ServiceDataGridView.ItemsSource = DatabaseControl.GetServiceForView();
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            Service z = ServiceDataGridView.SelectedItem as Service;
            if (z != null)
            {
                DatabaseControl.DelService(z);
                ServiceDataGridView.ItemsSource = null;
                ServiceDataGridView.ItemsSource = DatabaseControl.GetServiceForView();
            }
            else
            {
                MessageBox.Show("Выберите элемент для удаления");

            }
        }
        private void searchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ServiceDataGridView.ItemsSource = ctx.Service.Where(c => c.Name.ToLower().Contains(searchTextBox.Text.ToLower())).ToList();
            }
        }
    }
}
