﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace AutoMoska.ClassEntity
{
    public class Product
    {
        [Key] public int ProductId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
        public double Price { get; set; }
        public List<Finance> FinanceEntities { get; set; }
        public List<AutoProduct> AutoProductEntities { get; set; }
        static public class gridRefThree
        {
            static public DataGrid grid { get; set; }
        }

    }
}
