﻿using AutoMoska.ClassEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static AutoMoska.ClassEntity.Finance;

namespace AutoMoska.AddWindows
{
    /// <summary>
    /// Логика взаимодействия для AddReport.xaml
    /// </summary>
    public partial class AddReport : Window
    {
        public double totalCost;
        public Auto? tempAuto = new Auto();
        public Product? tempProduct = new Product();
        public Service? tempService = new Service();
        public AddReport()
        {
            InitializeComponent();
            
            LastNameClient.ItemsSource = DatabaseControl.GetClientForView();
            LastNameWorker.ItemsSource = DatabaseControl.GetWorkerForView();
            Auto.ItemsSource = DatabaseControl.GetAutoForView();
            Product.ItemsSource = DatabaseControl.GetProductForView();
            Service.ItemsSource = DatabaseControl.GetServiceForView();

        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {

            if (string.IsNullOrWhiteSpace(LastNameClient.Text) && string.IsNullOrWhiteSpace(LastNameWorker.Text) && (string.IsNullOrWhiteSpace(Auto.Text) || string.IsNullOrWhiteSpace(Product.Text) || string.IsNullOrWhiteSpace(Service.Text)))
            {
                MessageBox.Show("Необходимо заполнить данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

           

                DatabaseControl.AddFinance(new Finance
                {
                    ClientId = (int?)LastNameClient.SelectedValue,
                    WorkerId = Convert.ToInt32(LastNameWorker.SelectedValue),
                    AutoId = (int?)(Auto.SelectedValue),
                    ProductId = (int?)(Product.SelectedValue),
                    ServiceId = (int?)(Service.SelectedValue),
                    Date = DateTime.UtcNow,
                    Amount = totalCost,
                    

                });

                //(this.Owner as MainWindow).RefreshTable();

                gridRefSix.grid.ItemsSource = null;
                gridRefSix.grid.ItemsSource = DatabaseControl.GetFinanceForView();
                this.Close();
            
        }
        
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (Auto.SelectedValue == null)
            {
                tempAuto.Price = 0;
            }
            else
            {
                tempAuto = DatabaseControl.GetAutoForView().Where(p => p.AutoId == Convert.ToInt32(Auto.SelectedValue)).Single();
            }

            if (Product.SelectedValue == null)
            {
                tempProduct.Price = 0;
            }
            else
            {
                tempProduct = DatabaseControl.GetProductForView().Where(p => p.ProductId == Convert.ToInt32(Product.SelectedValue)).Single();
            }

            if (Service.SelectedValue == null)
            {
                tempService.Price = 0;
            }
            else
            {  
                tempService = DatabaseControl.GetServiceForView().Where(p => p.ServiceId == Convert.ToInt32(Service.SelectedValue)).Single();
            }

            totalCost = Math.Round(tempAuto.Price + tempProduct.Price + tempService.Price, 2);
            TotalCost.Text = totalCost.ToString();
        }
    }
}
