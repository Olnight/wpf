<?php

class Cat {
    public $id;
}