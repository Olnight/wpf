﻿using AutoMoska.ClassEntity;
using AutoMoska.AddWindows;
using AutoMoska.EditWindows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static AutoMoska.ClassEntity.Worker;

namespace AutoMoska.Pages
{
    /// <summary>
    /// Логика взаимодействия для WorkerPage.xaml
    /// </summary>
    public partial class WorkerPage : Page
    {
        public WorkerPage()
        {
            InitializeComponent();
            WorkerDataGridView.ItemsSource = DatabaseControl.GetWorkerForView();
        }
        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            AddWorker win = new AddWorker();
            gridRefFive.grid = WorkerDataGridView;
            win.ShowDialog();
        }
        private void editButton_Click(object sender, RoutedEventArgs e)
        {

            Worker c = WorkerDataGridView.SelectedItem as Worker;
            gridRefFive.grid = WorkerDataGridView;
            if (c != null)
            {
                EditWorker eddWorker = new EditWorker(c);
                eddWorker.Show();
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }
        }

        public void RefreshTable()
        {
            WorkerDataGridView.ItemsSource = null;
            WorkerDataGridView.ItemsSource = DatabaseControl.GetWorkerForView();
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            Worker z = WorkerDataGridView.SelectedItem as Worker;
            if (z != null)
            {

                DatabaseControl.DelWorker(z);
                WorkerDataGridView.ItemsSource = null;
                WorkerDataGridView.ItemsSource = DatabaseControl.GetWorkerForView();
            }
            else
            {
                MessageBox.Show("Выберите элемент для удаления");

            }
        }
        private void searchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                WorkerDataGridView.ItemsSource = ctx.Worker.Where(c => c.FirstName.ToLower().Contains(searchTextBox.Text.ToLower()) ||
                                                                       c.LastName.ToLower().Contains(searchTextBox.Text.ToLower()) ||
                                                                       c.Patronymic.ToLower().Contains(searchTextBox.Text.ToLower()) ||
                                                                       c.Phone.Contains(searchTextBox.Text)).ToList();
            }
        }
    }
}
