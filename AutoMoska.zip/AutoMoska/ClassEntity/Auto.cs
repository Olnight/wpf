﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Windows.Controls;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace AutoMoska.ClassEntity
{
    public class Auto
    {
        [Key] public int AutoId { get; set; }
        public string Model { get; set; }
        public string Brand { get; set; }
        public string Сonstruction { get; set; }
        public string Description { get; set; }
        public string Motor { get; set; }
        public string Gearbox { get; set; }
        public string Drive { get; set; }
        public string Color { get; set; }
        public double Price { get; set; }
        public List<Finance> FinanceEntities { get; set; }
        public List<AutoProduct> AutoProductEntities { get; set; }
        static public class gridRefTwo
        {
            static public DataGrid grid { get; set; }
        }

    }
}
