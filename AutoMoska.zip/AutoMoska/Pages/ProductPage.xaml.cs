﻿using AutoMoska.ClassEntity;
using AutoMoska.EditWindows;
using AutoMoska.AddWindows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static AutoMoska.ClassEntity.Product;

namespace AutoMoska.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductPage.xaml
    /// </summary>
    public partial class ProductPage : Page
    {
        public ProductPage()
        {
            InitializeComponent();
         

            productsListView.ItemsSource = from Product in DatabaseControl.GetProductForView()
                                           group Product
                                           by Product.Category;

            ProductDataGridView.ItemsSource = from Product in DatabaseControl.GetProductForView()
                                            where !string.IsNullOrEmpty(Product.Name)
                                            select Product;
        }
        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            AddProduct win = new AddProduct();
            gridRefThree.grid = ProductDataGridView;
            win.ShowDialog();
        }
        private void editButton_Click(object sender, RoutedEventArgs e)
        {

            Product c = ProductDataGridView.SelectedItem as Product;
            gridRefThree.grid = ProductDataGridView;
            if (c != null)
            {
                EditProduct eddProduct = new EditProduct(c);
                eddProduct.Show();
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }
        }
        public void RefreshTable()
        {
            ProductDataGridView.ItemsSource = null;
            ProductDataGridView.ItemsSource = DatabaseControl.GetProductForView();
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            Product z = ProductDataGridView.SelectedItem as Product;
            if (z != null)
            {
                DatabaseControl.DelProduct(z);
                ProductDataGridView.ItemsSource = null;
                ProductDataGridView.ItemsSource = DatabaseControl.GetProductForView();
            }
            else
            {
                MessageBox.Show("Выберите элемент для удаления");

            }
        }

        private void ProductDataGridView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            //AutoProduct Temp1 = mainDataGridView.SelectedItem as Finance;
            //if (Temp1.AutoId != null)
            //{
            //    int? AutoId = Temp1.AutoId;
            //    AutoBox.ItemsSource = DatabaseControl.GetAutoForListBox(AutoId);
            //}
            //else
            //{
            //    AutoBox.Visibility = Visibility.Collapsed;
            //}
        }
        private void productsListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox comboBox = sender as ComboBox;
            ComboBoxItem comboBoxItem = comboBox.ItemContainerGenerator.ContainerFromItem(comboBox.SelectedItem) as ComboBoxItem;
            if (comboBoxItem == null)
            {
                return;
            }
            TextBlock textBlock = FindVisualChildByName<TextBlock>(comboBoxItem, "categoryTextBlock");
            if (textBlock.Text == "Все")
            {
                ProductDataGridView.ItemsSource = from Product in DatabaseControl.GetProductForView()
                                                  where Product.Category != textBlock.Text && !string.IsNullOrEmpty(Product.Name)
                                                  select Product;
            }
            else
            {
                ProductDataGridView.ItemsSource = from Product in DatabaseControl.GetProductForView()
                                                  where Product.Category == textBlock.Text && !string.IsNullOrEmpty(Product.Name)
                                                  select Product;
            }
            ProductDataGridView.ScrollIntoView(ProductDataGridView.Items.GetItemAt(0));
        }
        // Поиск категории для фильтрации в TextBlock
        private static T FindVisualChildByName<T>(DependencyObject parent, string name) where T : DependencyObject
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                string controlName = child.GetValue(NameProperty) as string;
                if (controlName == name)
                {
                    return child as T;
                }
                T result = FindVisualChildByName<T>(child, name);
                if (result != null)
                    return result;
            }
            return null;
        }
    }
}
