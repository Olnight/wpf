﻿using AutoMoska.ClassEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static AutoMoska.ClassEntity.Auto;

namespace AutoMoska.AddWindows
{
    /// <summary>
    /// Логика взаимодействия для AddAuto.xaml
    /// </summary>
    public partial class AddAuto : Window
    {
        public AddAuto()
        {
            InitializeComponent(); 
        }
        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            Regex regexModelBrand = new Regex(@"^(?:[А-Я][А-Яа-я]{1,29}|[A-Z][A-Za-z]{1,29})$");
            Regex regexMotor = new Regex(@"^(?:[А-Яа-я0-9\s]{2,20})$");
            Regex regexPrice = new Regex(@"^\d{1,8}\,\d{2}$");


            if (string.IsNullOrWhiteSpace(AutoModel.Text) && string.IsNullOrWhiteSpace(AutoBrand.Text) && string.IsNullOrWhiteSpace(AutoСonstruction.Text) && string.IsNullOrWhiteSpace(AutoDescription.Text) && string.IsNullOrWhiteSpace(AutoMotor.Text) && string.IsNullOrWhiteSpace(AutoGearbox.Text) && string.IsNullOrWhiteSpace(AutoDrive.Text) && string.IsNullOrWhiteSpace(AutoColor.Text) && string.IsNullOrWhiteSpace(AutoColor.Text))
            {
                MessageBox.Show("Необходимо заполнить данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if ((AutoModel.Text != "") && (AutoBrand.Text != "") && (AutoСonstruction.Text != "") && (AutoDescription.Text != "") && (AutoMotor.Text != "") && (AutoGearbox.Text != "") && (AutoDrive.Text != "") && (AutoColor.Text != "") && (AutoPrice.Text != ""))
            {
                try
                {
                    Convert.ToDouble(AutoPrice.Text);
                    if (regexModelBrand.IsMatch(AutoModel.Text))
                    {
                        if (regexModelBrand.IsMatch(AutoBrand.Text))
                        {

                                if (regexMotor.IsMatch(AutoMotor.Text))
                                {
                                    if (regexPrice.IsMatch(AutoPrice.Text))
                                    {
                                        Auto _tempAuto = new Auto();
                                        _tempAuto.Model = AutoModel.Text;
                                        _tempAuto.Brand = AutoBrand.Text;
                                        _tempAuto.Сonstruction = AutoСonstruction.Text;
                                        _tempAuto.Description = AutoDescription.Text;
                                        _tempAuto.Motor = AutoMotor.Text;
                                        _tempAuto.Gearbox = AutoGearbox.Text;
                                        _tempAuto.Drive = AutoDrive.Text;
                                        _tempAuto.Color = AutoColor.Text;
                                        _tempAuto.Price = Convert.ToDouble(AutoPrice.Text);

                                        DatabaseControl.AddAuto(new Auto
                                        {
                                            Model = AutoModel.Text,
                                            Brand = AutoBrand.Text,
                                            Сonstruction = AutoСonstruction.Text,
                                            Description = AutoDescription.Text,
                                            Motor = AutoMotor.Text,
                                            Gearbox = AutoGearbox.Text,
                                            Drive = AutoDrive.Text,
                                            Color = AutoColor.Text,
                                            Price = Convert.ToDouble(AutoPrice.Text)
                                        });

                                        (this.Owner as MainWindow).RefreshTable();

                                        //gridRefTwo.grid.ItemsSource = null;
                                        //gridRefTwo.grid.ItemsSource = DatabaseControl.GetAutoForView();
                                        this.Close();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Неверно указан формат цены", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Неверно указан формат мотора", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                }

                        }
                        else
                        {
                            MessageBox.Show("Неверный формат бренда", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Неверный формат модели", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch
                {
                    MessageBox.Show("Необходимо заполнить данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
