﻿using AutoMoska.ClassEntity;
using AutoMoska.AddWindows;
using AutoMoska.EditWindows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static AutoMoska.ClassEntity.Finance;
using Microsoft.EntityFrameworkCore;


namespace AutoMoska.Pages
{
    /// <summary>
    /// Логика взаимодействия для ReportPage.xaml
    /// </summary>
    public partial class ReportPage : Page
    {
        public ReportPage()
        {
            InitializeComponent();
            //List<Finance> Temp = DatabaseControl.GetAmountForView();

            //double summ = 
            ReportDataGridView.ItemsSource = DatabaseControl.GetFinanceForView();
            gridRefSix.grid = ReportDataGridView;
            //Finance temp = mainDataGridView.SelectedItem as Finance;
            //double summ = 0;
            //if(temp.AutoId != null)
            //{
            //    summ += temp.AutoEntity.Price;
            //}
            //if (temp.ServiceId != null)
            //{
            //    summ += temp.ServiceEntity.Price;
            //}
            //if (temp.ProductId != null)
            //{
            //    summ += temp.ProductEntity.Price;
            //}
        }

        private void mainDataGridView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Finance Temp1 = ReportDataGridView.SelectedItem as Finance;
            if (Temp1.AutoId != null)
            {
                int? AutoId = Temp1.AutoId;
                AutoBox.ItemsSource = DatabaseControl.GetAutoForListBox(AutoId);
            }
            else
            {
                AutoBox.Visibility = Visibility.Collapsed;
            }

            Finance Temp2 = ReportDataGridView.SelectedItem as Finance;
            if (Temp2.ServiceId != null)
            {
                int? ServiceId = Temp2.ServiceId;
                ServiceBox.ItemsSource = DatabaseControl.GetServiceForListBox(ServiceId);
            }
            else
            {
                ServiceBox.Visibility = Visibility.Collapsed;
            }



            Finance Temp3 = ReportDataGridView.SelectedItem as Finance;
            if (Temp3.ProductId != null)
            {
                int? ProductId = Temp3.ProductId;
                ProductBox.ItemsSource = DatabaseControl.GetProductForListBox(ProductId);
            }
            else
            {
                ProductBox.Visibility = Visibility.Collapsed;
            }
        }
        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            AddReport win = new AddReport();
            gridRefSix.grid = ReportDataGridView;
            win.ShowDialog();
        }
        private void searchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ReportDataGridView.ItemsSource = ctx.Finance.Include(p => p.ClientEntity).Include(p => p.WorkerEntity)
                    .Where(p =>
                    p.ClientEntity.FirstName.ToLower().Contains(searchTextBox.Text.ToLower()) ||
                    p.ClientEntity.LastName.ToLower().Contains(searchTextBox.Text.ToLower()) ||
                    p.ClientEntity.Patronymic.ToLower().Contains(searchTextBox.Text.ToLower()) ||
                    p.WorkerEntity.FirstName.ToLower().Contains(searchTextBox.Text.ToLower()) ||
                    p.WorkerEntity.Patronymic.ToLower().Contains(searchTextBox.Text.ToLower()) ||
                    p.WorkerEntity.LastName.ToLower().Contains(searchTextBox.Text.ToLower())).ToList();
            }
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            Finance z = ReportDataGridView.SelectedItem as Finance;
            if (z != null)
            {
                DatabaseControl.DelFinance(z);
                ReportDataGridView.ItemsSource = null;
                ReportDataGridView.ItemsSource = DatabaseControl.GetFinanceForView();
            }
            else
            {
                MessageBox.Show("Выберите элемент для удаления");

            }
        }
        //private void editButton_Click(object sender, RoutedEventArgs e)
        //{

        //    Client c = mainDataGridView.SelectedItem as Client;
        //    gridRefSix.grid = mainDataGridView;
        //    if (c != null)
        //    {
        //        EditFinance eddClient = new EditFinance(c);
        //        eddFinance.Show();
        //    }
        //    else
        //    {
        //        MessageBox.Show("Выберите элемент для изменения");
        //    }
        //}
        //public void RefreshTable()
        //{
        //    mainDataGridView.ItemsSource = null;
        //    mainDataGridView.ItemsSource = DatabaseControl.GetClientForView();
        //}

        //private void removeButton_Click(object sender, RoutedEventArgs e)
        //{
        //    Client z = ClientDataGridView.SelectedItem as Client;
        //    if (z != null)
        //    {
        //        DatabaseControl.DelClient(z);
        //        ClientDataGridView.ItemsSource = null;
        //        ClientDataGridView.ItemsSource = DatabaseControl.GetClientForView();
        //    }
        //    else
        //    {
        //        MessageBox.Show("Выберите элемент для удаления");

        //    }
        //}


    }
}
