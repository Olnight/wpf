﻿using AutoMoska.ClassEntity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography.X509Certificates;

namespace AutoMoska
{
    public static class DatabaseControl
    {

        public static List<Client> GetClientForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Client.ToList();
            }
        }
        public static List<Worker> GetWorkerForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Worker.ToList();
            }
        }
        public static List<Service> GetServiceForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Service.ToList();
            }
        }
        public static List<Product> GetProductForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                List<Product> products = ctx.Product.Include(p => p.AutoProductEntities).ToList();
                products.Insert(0, new Product { Category = "Все" });
                return products;
            }
        }
        public static List<Auto> GetAutoForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Auto.Include(p => p.AutoProductEntities).ToList();
            }
        }


        public static List<Finance> GetFinanceForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Finance.Include(p => p.ClientEntity).Include(p => p.WorkerEntity).Include(p => p.AutoEntity).Include(p => p.ProductEntity).Include(p => p.ServiceEntity).ToList();
                //return ctx.Finance.Include(p => p.ClientEntity).Include(p => p.WorkerEntity).Include(p => p.AutoEntity).Include(p => p.ProductEntity).Include(p => p.ServiceEntity).Where(p => p.ProductEntity.Price || p.ServiceEntity.Price || p.AutoEntity.Price).Sum(f => f.Amount).ToList();
            }
        }
        //ListBoxReport
        public static List<Finance> GetAutoForListBox(int? AutoId)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Finance.Include(p => p.AutoEntity).Where(p => p.AutoId == AutoId).ToList();
            }
        }
        public static List<Finance> GetProductForListBox(int? ProductId)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Finance.Include(p => p.ProductEntity).Where(p => p.ProductId == ProductId).ToList();
            }
        }
        public static List<Finance> GetServiceForListBox(int? ServiceId)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Finance.Include(p => p.ServiceEntity).Where(p => p.ServiceId == ServiceId).ToList();
            }
        }
        //public static List<Finance> GetAmountForView()
        //{
        //    using (DbAppContext ctx = new DbAppContext())
        //    {
        //        return ctx.Finance.Include(p => p.AutoEntity).Include(p => p.ProductEntity).Include(p => p.ServiceEntity).Where(f => f.AutoId != null || f.ProductId != null || f.ServiceId != null).ToList();
        //    }
        //}

        //Добавление
        public static void AddFinance(Finance? Finance)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Finance.Add(Finance);
                ctx.SaveChanges();
            }
        }
        public static void AddClient(Client Client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Client.Add(Client);
                ctx.SaveChanges();
            }
        }
        public static void AddWorker(Worker Worker)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Worker.Add(Worker);
                ctx.SaveChanges();
            }
        }
        public static void AddService(Service Service)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Service.Add(Service);
                ctx.SaveChanges();
            }
        }
        public static void AddAuto(Auto Auto)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Auto.Add(Auto);
                ctx.SaveChanges();
            }
        }
        public static void AddProduct(Product Product)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Product.Add(Product);
                ctx.SaveChanges();
            }
        }


        //Удаление
        public static void DelFinance(Finance Finance)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Finance.Remove(Finance);
                ctx.SaveChanges();
            }
        }
        public static void DelClient(Client Client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Client.Remove(Client);
                ctx.SaveChanges();
            }
        }
        public static void DelService(Service Service)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Service.Remove(Service);
                ctx.SaveChanges();
            }
        }
        public static void DelWorker(Worker Worker)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Worker.Remove(Worker);
                ctx.SaveChanges();
            }
        }
        public static void DelAuto(Auto Auto)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Auto.Remove(Auto);
                ctx.SaveChanges();
            }
        }
        public static void DelProduct(Product Product)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Product.Remove(Product);
                ctx.SaveChanges();
            }
        }

        //Редактирование

        public static void UpdateClient(Client Client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                Client _Client = ctx.Client.FirstOrDefault(p => p.ClientId == Client.ClientId);
                if (_Client == null)
                {
                    return;
                }
                _Client.FirstName = Client.FirstName;
                _Client.LastName = Client.LastName;
                _Client.Patronymic = Client.Patronymic;
                _Client.Phone = Client.Phone;
                ctx.SaveChanges();
            }
        }

        public static void UpdateWorker(Worker Worker)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                Worker _Worker = ctx.Worker.FirstOrDefault(p => p.WorkerId == Worker.WorkerId);
                if (_Worker == null)
                {
                    return;
                }
                _Worker.FirstName = Worker.FirstName;
                _Worker.LastName = Worker.LastName;
                _Worker.Patronymic = Worker.Patronymic;
                _Worker.Post = Worker.Post;
                _Worker.Login = Worker.Login;
                _Worker.Password = Worker.Password;
                _Worker.Phone = Worker.Phone;
                ctx.SaveChanges();
            }
        }

        public static void UpdateAuto(Auto Auto)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                Auto _Auto = ctx.Auto.FirstOrDefault(p => p.AutoId == Auto.AutoId);
                if (_Auto == null)
                {
                    return;
                }
                _Auto.Model = Auto.Model;
                _Auto.Brand = Auto.Brand;
                _Auto.Сonstruction = Auto.Сonstruction;
                _Auto.Description = Auto.Description;
                _Auto.Motor = Auto.Motor;
                _Auto.Gearbox = Auto.Gearbox;
                _Auto.Drive = Auto.Drive;
                _Auto.Color = Auto.Color;
                _Auto.Price = Auto.Price;

                ctx.SaveChanges();
            }
        }

        public static void UpdateService(Service Service)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                Service _Service = ctx.Service.FirstOrDefault(p => p.ServiceId == Service.ServiceId);
                if (_Service == null)
                {
                    return;
                }
                _Service.Name = Service.Name;
                _Service.Description = Service.Description;
                _Service.Duration = Service.Duration;
                _Service.Price = Service.Price;
                ctx.SaveChanges();
            }
        }

        public static void UpdateProduct(Product Product)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                Product _Product = ctx.Product.FirstOrDefault(p => p.ProductId == Product.ProductId);
                if (_Product == null)
                {
                    return;
                }
                _Product.Name = Product.Name;
                _Product.Description = Product.Description;
                _Product.Category = Product.Category;
                _Product.Price = Product.Price;
                ctx.SaveChanges();
            }
        }


        //public static List<Company> GetCompanyForView()
        //{
        //    using (DbAppContext ctx = new DbAppContext())
        //    {
        //        return ctx.Company.Include(p => p.PhoneEntites).ToList();
        //    }
        //}

        //public static void AddPhone(Phone phone)
        //{
        //    using (DbAppContext ctx = new DbAppContext())
        //    {
        //        ctx.Phone.Add(phone);
        //        ctx.SaveChanges();
        //    }
        //}
        //public static void DelPhone(Phone phone)
        //{
        //    using (DbAppContext ctx = new DbAppContext())
        //    {
        //        ctx.Phone.Remove(phone);
        //        ctx.SaveChanges();
        //    }
        //}

        //public static void UpdatePhone(Phone phone)
        //{
        //    using (DbAppContext ctx = new DbAppContext())
        //    {
        //        Phone _phone = ctx.Phone.FirstOrDefault(p => p.Id == phone.Id);

        //        if (_phone == null)
        //        {
        //            return;
        //        }

        //        _phone.Title = phone.Title;
        //        _phone.Price = phone.Price;
        //        _phone.CompanyId = phone.CompanyId;
        //        _phone.Definition = phone.Definition;
        //        _phone.Image = phone.Image;

        //        ctx.SaveChanges();
        //    }
        //}
    }
}
