<?php

require_once 'Point.php';
require_once 'PointFunctions.php';

// Тесты
$point1 = new Point();
$point1->x = 1;
$point1->y = 10;

$point2 = new Point();
$point2->x = 10;
$point2->y = 1;
 
$midpoint = getMidpoint($point1, $point2);

echo "Точка 1: ({$point1->x}, {$point1->y})\n";
echo "Точка 2: ({$point2->x}, {$point2->y})\n";
echo "Середина отрезка: ({$midpoint->x}, {$midpoint->y})\n";  // Ожидаемый вывод: (5.5, 5.5)
