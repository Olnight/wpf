﻿using AutoMoska.ClassEntity;
using AutoMoska.EditWindows;
using AutoMoska.AddWindows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static AutoMoska.ClassEntity.Client;

namespace AutoMoska.Pages
{
    /// <summary>
    /// Логика взаимодействия для ClientPage.xaml
    /// </summary>
    public partial class ClientPage : Page
    {
        public ClientPage()
        {
            InitializeComponent();
            ClientDataGridView.ItemsSource = DatabaseControl.GetClientForView();        
        }
        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            AddClient win = new AddClient();
            gridRefOne.grid = ClientDataGridView;
            win.ShowDialog();
        }
        private void editButton_Click(object sender, RoutedEventArgs e)
        {

            Client c = ClientDataGridView.SelectedItem as Client;
            gridRefOne.grid = ClientDataGridView;
            if (c != null)
            {
                EditClient eddClient = new EditClient(c);
                eddClient.Show();
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }
        }
        public void RefreshTable()
        {
            ClientDataGridView.ItemsSource = null;
            ClientDataGridView.ItemsSource = DatabaseControl.GetClientForView();
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            Client z = ClientDataGridView.SelectedItem as Client;
            if (z != null)
            {
                DatabaseControl.DelClient(z);
                ClientDataGridView.ItemsSource = null;
                ClientDataGridView.ItemsSource = DatabaseControl.GetClientForView();
            }
            else
            {
                MessageBox.Show("Выберите элемент для удаления");

            }
        }
        private void searchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ClientDataGridView.ItemsSource = ctx.Client.Where(c => c.FirstName.ToLower().Contains(searchTextBox.Text.ToLower()) ||
                                                                       c.LastName.ToLower().Contains(searchTextBox.Text.ToLower()) ||
                                                                       c.Patronymic.ToLower().Contains(searchTextBox.Text.ToLower()) ||
                                                                       c.Phone.Contains(searchTextBox.Text)).ToList();
            }
        }
    }
}
