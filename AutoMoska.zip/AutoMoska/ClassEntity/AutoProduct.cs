﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using System.Windows.Controls;


namespace AutoMoska.ClassEntity
{
    public class AutoProduct
    {
        [Key] public int AutoProductId { get; set; }
        [ForeignKey("AutoEntity")] public int AutoId { get; set; }
        [ForeignKey("ProductEntity")] public int ProductId { get; set; }
        public Auto AutoEntity { get; set; }
        public Product ProductEntity { get; set; }
        static public class gridRef
        {
            static public DataGrid grid { get; set; }
        }
    }
}
