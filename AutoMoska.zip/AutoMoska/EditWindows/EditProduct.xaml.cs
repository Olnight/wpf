﻿using AutoMoska.ClassEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static AutoMoska.ClassEntity.Product;

namespace AutoMoska.EditWindows
{
    /// <summary>
    /// Логика взаимодействия для EditProduct.xaml
    /// </summary>
    public partial class EditProduct : Window
    {

        Product _tempProduct = new Product();
        public EditProduct(Product Product)
        {
            InitializeComponent();
            _tempProduct = Product;
            ProductName.Text = Product.Name;
            ProductDescription.Text = Product.Description;
            ProductCategory.Text = Product.Category;
            ProductPrice.Text = Product.Price.ToString();
        }

        private void Button_Cancel(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void Button_Ok(object sender, RoutedEventArgs e)
        {
            Regex regexName = new Regex(@"^(?:[А-ЯA-Z][А-Яа-яA-Za-z0-9]{1,49})$");
            Regex regexDescription = new Regex(@"^(?:[А-Я][А-Яа-я0-9\s]{10,199})$");
            Regex regexCategory = new Regex(@"^(?:[А-Я][А-Яа-я]{1,49})$");
            Regex regexPrice = new Regex(@"^\d{1,8}\,\d{2}$");


            if (string.IsNullOrWhiteSpace(ProductName.Text) && string.IsNullOrWhiteSpace(ProductDescription.Text) && string.IsNullOrWhiteSpace(ProductCategory.Text) && string.IsNullOrWhiteSpace(ProductPrice.Text))
            {
                MessageBox.Show("Необходимо заполнить данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if ((ProductName.Text != "") && (ProductDescription.Text != "") && (ProductCategory.Text != "") && (ProductPrice.Text != ""))
            {
                try
                {
                    Convert.ToDouble(ProductPrice.Text);
                    if (regexName.IsMatch(ProductName.Text))
                    {
                        if (regexDescription.IsMatch(ProductDescription.Text))
                        {
                                if (regexPrice.IsMatch(ProductPrice.Text))
                                {
                                    _tempProduct.Name = ProductName.Text;
                                    _tempProduct.Description = ProductDescription.Text;
                                    _tempProduct.Category = ProductCategory.Text;
                                    _tempProduct.Price = Convert.ToDouble(ProductPrice.Text);

                                    DatabaseControl.UpdateProduct(_tempProduct);

                                    gridRefThree.grid.ItemsSource = null;
                                    gridRefThree.grid.ItemsSource = DatabaseControl.GetProductForView();
                                    this.Close();
                                }
                                else
                                {
                                    MessageBox.Show("Неверный формат цены", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                }
                        }
                        else
                        {
                            MessageBox.Show("Неверный формат описания", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Неверный формат имени клиента", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch
                {
                    MessageBox.Show("Необходимо заполнить данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
