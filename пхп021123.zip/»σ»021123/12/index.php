<?php

require_once 'autoloader.php';

$segment = new Segment(new Point(1, 10), new Point(11, -3));

echo "Исходный отрезок: \n";
echo "Begin Point: ({$segment->beginPoint->x}, {$segment->beginPoint->y})\n";
echo "End Point: ({$segment->endPoint->x}, {$segment->endPoint->y})\n";

$reversedSegment = reverse($segment);

echo "Перевернутый отрезок: \n";
echo "Begin Point: ({$reversedSegment->beginPoint->x}, {$reversedSegment->beginPoint->y})\n";  // Ожидаемый вывод: (11, -3)
echo "End Point: ({$reversedSegment->endPoint->x}, {$reversedSegment->endPoint->y})\n";        // Ожидаемый вывод: (1, 10)