<?php

require_once 'Rational.php';

$rat1 = new Rational(3, 9);
echo "Rational 1: {$rat1->getNumer()}/{$rat1->getDenom()}\n";  // Ожидаемый вывод: 3/9

$rat2 = new Rational(10, 3);
echo "Rational 2: {$rat2->getNumer()}/{$rat2->getDenom()}\n";  // Ожидаемый вывод: 10/3

$rat3 = $rat1->add($rat2);
echo "Rational 1 + Rational 2: {$rat3->getNumer()}/{$rat3->getDenom()}\n";  // Ожидаемый вывод: 99/27

$rat4 = $rat1->sub($rat2);
echo "Rational 1 - Rational 2: {$rat4->getNumer()}/{$rat4->getDenom()}\n";  // Ожидаемый вывод: -81/27