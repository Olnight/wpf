﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AutoMoska.ClassEntity;
using AutoMoska.AddWindows;
using AutoMoska.EditWindows;
using static AutoMoska.ClassEntity.Auto;
using AutoMoska.Pages;

namespace AutoMoska
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        string TempWorker;
        public MainWindow(string LastName, string Post)
        {
            InitializeComponent();

            LastNameWorker.Text = LastName;
            TempWorker = Post;
            PostWorker.Text = Post;

            AutoDataGridView.ItemsSource = DatabaseControl.GetAutoForView();

            if (TempWorker != "Администратор")
            {
                reports.Visibility = Visibility.Collapsed;
                workers.Visibility = Visibility.Collapsed;
                addButton.Visibility = Visibility.Collapsed;
                DataGridRemEdit.Visibility = Visibility.Collapsed;
                MenuEdit.Visibility = Visibility.Collapsed;
                MenuRemove.Visibility = Visibility.Collapsed;
            }
        }
        private void autos_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = null;
            AutoDataGridView.ItemsSource = DatabaseControl.GetAutoForView();
        }

        private void clients_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = null;
            PageFrame.Content = new ClientPage();
        }

        private void products_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = null;
            PageFrame.Content = new ProductPage();
        }

        private void services_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = null;
            PageFrame.Content = new ServicePage();
        }

        private void workes_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = null;
            PageFrame.Content = new WorkerPage();
        }
        private void reportes_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = null;
            PageFrame.Content = new ReportPage();
        }





        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            AddAuto win = new AddAuto();
            win.Owner = this;
            //gridRefTwo.grid = AutoDataGridView;
            win.Show();
        }
        private void editButton_Click(object sender, RoutedEventArgs e)
        {

            Auto c = AutoDataGridView.SelectedItem as Auto;
            //gridRefTwo.grid = AutoDataGridView;
            if (c != null)
            {
                EditAuto eddAuto = new EditAuto(c);
                eddAuto.Owner = this;

                eddAuto.Show();
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }
        }

        public void RefreshTable()
        {
            AutoDataGridView.ItemsSource = null;
            AutoDataGridView.ItemsSource = DatabaseControl.GetAutoForView();
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            Auto z = AutoDataGridView.SelectedItem as Auto;
            if (z != null)
            {
                DatabaseControl.DelAuto(z);
                AutoDataGridView.ItemsSource = null;
                AutoDataGridView.ItemsSource = DatabaseControl.GetAutoForView();
            }
            else
            {
                MessageBox.Show("Выберите элемент для удаления");

            }
        }
        private void searchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                AutoDataGridView.ItemsSource = ctx.Auto.Where(c => c.Model.ToLower().Contains(searchTextBox.Text.ToLower())).ToList();
            }
        }
    }
}
