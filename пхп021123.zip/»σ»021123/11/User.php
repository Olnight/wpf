<?php

class User {
    public $id;
}