﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Windows.Controls;
using System.ComponentModel.DataAnnotations.Schema;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace AutoMoska.ClassEntity
{
    public class Service
    {
        [Key] public int ServiceId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int Duration { get; set; }
        public double Price { get; set; }
        public List<Finance> FinanceEntities { get; set; }
        static public class gridRefFour
        {
            static public DataGrid grid { get; set; }
        }
    }
}
