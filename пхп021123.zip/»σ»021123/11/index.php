<?php

require_once 'autoloader.php';

// Тестирование функции areUsersEqual
$user1 = new User();
$user1->id = 1;

$user2 = new User();
$user2->id = 1;

echo areUsersEqual($user1, $user2) ? "Пользователи равны\n" : "Пользователи не равны\n"; // Пользователи равны

$user3 = new User();
$user3->id = 3;

echo areUsersEqual($user1, $user3) ? "Пользователи равны\n" : "Пользователи не равны\n"; // Пользователи не равны
echo areUsersEqual($user2, $user3) ? "Пользователи равны\n" : "Пользователи не равны\n"; // Пользователи не равны


// Пробуем сравнить пользователя с кошкой 
$cat = new Cat();
$cat->id = 1;
echo areUsersEqual($user1, $cat); 