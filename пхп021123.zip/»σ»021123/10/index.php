<?php

require_once 'autoloader.php';

// Тестирование функции dup
$point1 = new Point();
$point1->x = 3;
$point1->y = 4;

$point2 = dup($point1);

echo "Точка 1: ({$point1->x}, {$point1->y})\n";
echo "Точка 2: ({$point2->x}, {$point2->y})\n";

// Проверка равенства значений
if ($point1 == $point2) {
    echo "Точки имеют одинаковые значения.\n";
} else {
    echo "Точки имеют разные значения.\n";
}

// Проверка идентичности объектов
if ($point1 === $point2) {
    echo "Точки идентичны.\n";
} else {
    echo "Точки не идентичны.\n"; // Ожидаемый вывод
}