﻿using AutoMoska.ClassEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static AutoMoska.ClassEntity.Client;


namespace AutoMoska.AddWindows
{
    /// <summary>
    /// Логика взаимодействия для AddClient.xaml
    /// </summary>
    public partial class AddClient : Window
    {
        public AddClient()
        {
            InitializeComponent();
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            Regex regexWord = new Regex(@"^[А-Я][а-я]{1,20}$");
            Regex regexNumber = new Regex(@"^(?:\+7|8)\d{10}$");

            if (string.IsNullOrWhiteSpace(ClientFirstName.Text) && string.IsNullOrWhiteSpace(ClientPhoneNumber.Text) && string.IsNullOrWhiteSpace(ClientLastName.Text) && string.IsNullOrWhiteSpace(ClientPatronymic.Text))
            {
                MessageBox.Show("Необходимо заполнить данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if ((ClientFirstName.Text != "") && (ClientPhoneNumber.Text != "") && (ClientLastName.Text != "") && (ClientPatronymic.Text != ""))
            {
                try
                {
                    if (regexWord.IsMatch(ClientFirstName.Text))
                    {
                        if (regexWord.IsMatch(ClientLastName.Text))
                        {
                            if (regexWord.IsMatch(ClientPatronymic.Text))
                            {
                                if (regexNumber.IsMatch(ClientPhoneNumber.Text))
                                {
                                    Client _tempClient = new Client();
                                    _tempClient.FirstName = ClientFirstName.Text;
                                    _tempClient.LastName = ClientLastName.Text;
                                    _tempClient.Patronymic = ClientPatronymic.Text;
                                    _tempClient.Phone = ClientPhoneNumber.Text;

                                    DatabaseControl.AddClient(new Client
                                    {
                                        FirstName = ClientFirstName.Text,
                                        LastName = ClientLastName.Text,
                                        Patronymic = ClientPatronymic.Text,
                                        Phone = ClientPhoneNumber.Text
                                        //Discount = (int)Convert.ToDecimal(Client.Text)
                                    });

                                    gridRefOne.grid.ItemsSource = null;
                                    gridRefOne.grid.ItemsSource = DatabaseControl.GetClientForView();
                                    this.Close();
                                }
                                else
                                {
                                    MessageBox.Show("Неверно указан номер телефона", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Неверный формат отчества клиента", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }                  
                        else
                        {
                            MessageBox.Show("Неверный формат фамилии клиента", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }                  
                    else
                    {
                        MessageBox.Show("Неверный формат имени клиента", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch
                {
                    MessageBox.Show("Необходимо заполнить данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
