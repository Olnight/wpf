<?php

class Rational {
    private $numer;
    private $denom;

    public function __construct($numer, $denom) {
        if ($denom == 0) {
            throw new InvalidArgumentException("Знаменатель не может быть равен нулю.");
        }
        $this->numer = $numer;
        $this->denom = $denom;
    }

    public function getNumer() {
        return $this->numer;
    }

    public function getDenom() {
        return $this->denom;
    }

    public function add(Rational $other) {
        $newNumer = $this->numer * $other->denom + $this->denom * $other->numer;
        $newDenom = $this->denom * $other->denom;
        return new Rational($newNumer, $newDenom);
    }

    public function sub(Rational $other) {
        $newNumer = $this->numer * $other->denom - $this->denom * $other->numer;
        $newDenom = $this->denom * $other->denom;
        return new Rational($newNumer, $newDenom);
    }
}