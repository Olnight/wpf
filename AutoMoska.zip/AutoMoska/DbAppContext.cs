﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;

namespace AutoMoska
{
    public class DbAppContext : DbContext
    {
        public DbSet<ClassEntity.Product> Product { get; set; }
        public DbSet<ClassEntity.Auto> Auto { get; set; }
        public DbSet<ClassEntity.Service> Service { get; set; }
        public DbSet<ClassEntity.Worker> Worker { get; set; }
        public DbSet<ClassEntity.Client> Client { get; set; }
        public DbSet<ClassEntity.Finance> Finance { get; set; }
        public DbSet<ClassEntity.AutoProduct> AutoProduct { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql(
                "Host=localhost;Username=postgres;Password=2305;Database=12bd");

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ClassEntity.Finance>().HasOne(p => p.ClientEntity).WithMany(p => p.FinanceEntities).IsRequired(false);
            modelBuilder.Entity<ClassEntity.Finance>().HasOne(p => p.WorkerEntity).WithMany(p => p.FinanceEntities).IsRequired(false);
            modelBuilder.Entity<ClassEntity.Finance>().HasOne(p => p.AutoEntity).WithMany(p => p.FinanceEntities).IsRequired(false);
            modelBuilder.Entity<ClassEntity.Finance>().HasOne(p => p.ProductEntity).WithMany(p => p.FinanceEntities).IsRequired(false);
            modelBuilder.Entity<ClassEntity.Finance>().HasOne(p => p.ServiceEntity).WithMany(p => p.FinanceEntities).IsRequired(false);
            modelBuilder.Entity<ClassEntity.AutoProduct>().HasOne(p => p.AutoEntity).WithMany(p => p.AutoProductEntities).IsRequired(false);
            modelBuilder.Entity<ClassEntity.AutoProduct>().HasOne(p => p.ProductEntity).WithMany(p => p.AutoProductEntities).IsRequired(false);
        }

    }
}
