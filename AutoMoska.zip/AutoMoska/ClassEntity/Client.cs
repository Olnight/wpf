﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Windows.Controls;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace AutoMoska.ClassEntity
{
    public class Client
    {
        [Key] public int ClientId { get; set; }
        public string FirstName{ get; set; }
        public string LastName { get; set; }
        public string Patronymic { get; set; }
        public string Phone { get; set; }
        public List<Finance> FinanceEntities { get; set; }
        static public class gridRefOne
        {
            static public DataGrid grid { get; set; }
        }
    }
}
