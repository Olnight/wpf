﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Windows.Controls;
using System.ComponentModel.DataAnnotations.Schema;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace AutoMoska.ClassEntity
{
    public class Finance
    {
        [Key] public int FinanceId { get; set; }
        [ForeignKey("ClientEntity")] public int? ClientId { get; set; }
        [ForeignKey("WorkerEntity")] public int? WorkerId { get; set; }
        [ForeignKey("ServiceEntity")] public int? ServiceId { get; set; }
        [ForeignKey("ProductEntity")] public int? ProductId { get; set; }
        [ForeignKey("AutoEntity")] public int? AutoId { get; set; }

        public DateTime Date { get; set; }
        public double Amount { get; set; }
        public Client ClientEntity{ get; set; }
        public Worker WorkerEntity { get; set; }
        public Service? ServiceEntity { get; set; }
        public Product? ProductEntity { get; set; }
        public Auto? AutoEntity { get; set; }
        static public class gridRefSix
        {
            static public DataGrid grid { get; set; }
        }

    }
}
