﻿using AutoMoska.ClassEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static AutoMoska.ClassEntity.Service;

namespace AutoMoska.AddWindows
{
    /// <summary>
    /// Логика взаимодействия для AddService.xaml
    /// </summary>
    public partial class AddService : Window
    {
        public AddService()
        {
            InitializeComponent();
        }
        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            Regex regexName = new Regex(@"^(?:[А-Я][А-Яа-я\s]{1,49})$");
            Regex regexDescription = new Regex(@"^(?:[А-Я][А-Яа-я0-9\s]{10,199})$");
            Regex regexDuration = new Regex(@"^(?:[1-9]|[1-9][0-9]|1[0-1][0-9]|12[0-8])$");
            Regex regexPrice = new Regex(@"^\d{1,8}\,\d{2}$");
            Regex regexColor = new Regex(@"^(?:[А-Я][а-я]{5,20})$");


            if (string.IsNullOrWhiteSpace(ServiceName.Text) && string.IsNullOrWhiteSpace(ServiceDescription.Text) && string.IsNullOrWhiteSpace(ServiceDuration.Text) && string.IsNullOrWhiteSpace(ServicePrice.Text))
            {
                MessageBox.Show("Необходимо заполнить данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if ((ServiceName.Text != "") && (ServiceDescription.Text != "") && (ServiceDuration.Text != "") && (ServicePrice.Text != ""))
            {
                try
                {
                    Convert.ToDouble(ServicePrice.Text);
                    if (regexName.IsMatch(ServiceName.Text))
                    {
                        if (regexDescription.IsMatch(ServiceDescription.Text))
                        {
                            if (regexDuration.IsMatch(ServiceDuration.Text))
                            {
                                if (regexPrice.IsMatch(ServicePrice.Text))
                                {
                                    Service _tempService = new Service();
                                    _tempService.Name = ServiceName.Text;
                                    _tempService.Description = ServiceDescription.Text;
                                    _tempService.Duration = (int)Convert.ToDouble(ServiceDuration.Text);
                                    _tempService.Price = Convert.ToDouble(ServicePrice.Text);

                                    DatabaseControl.AddService(new Service
                                    {
                                        Name = ServiceName.Text,
                                        Description = ServiceDescription.Text,
                                        Duration = (int)Convert.ToDouble(ServiceDuration.Text),
                                        Price = Convert.ToDouble(ServicePrice.Text)
                                    });

                                    gridRefFour.grid.ItemsSource = null;
                                    gridRefFour.grid.ItemsSource = DatabaseControl.GetServiceForView();
                                    this.Close();
                                }
                                else
                                {
                                    MessageBox.Show("Неверный формат цены услуги", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Неверный формат срока услуги", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Неверный формат описания услуги", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Неверный формат названия услуги", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch
                {
                    MessageBox.Show("Необходимо заполнить данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
